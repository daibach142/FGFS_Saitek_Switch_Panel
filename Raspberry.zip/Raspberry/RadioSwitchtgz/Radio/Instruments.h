/*****************************************************************************
** File     : Instruments.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
** */

#ifndef INSTRUMENTS_H_
#define INSTRUMENTS_H_

// index the radios - common external terminology

#define COM1 0
#define COM2 1
#define NAV1 2
#define NAV2 3
#define ADF  4
#define DME  5
#define XPDR 6

// return string value of the device Active display
char * getActive(int deviceNumber);
// return string value of the device Standby display
char * getStandby(int deviceNumber);
// return the FGFS name property name for the device
char * getRadioName(int deviceNumber);
// show if the FGFS input radios string has changed
int getRadioChanged(void);

#endif /* INSTRUMENTS_H_ */
