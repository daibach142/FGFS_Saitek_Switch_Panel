/*****************************************************************************
** File     : main.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
** */

#ifndef MAIN_H_
#define MAIN_H_

//#define DEBUG
char device[20];
char server[20];

unsigned int STKRPInput;	// Compressed 3 bytes input from Radio Panel
char FGFSInput[120];		// 13 fields -- some spare! from FGFS

#endif /* MAIN_H_ */
