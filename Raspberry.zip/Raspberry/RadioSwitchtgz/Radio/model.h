/*****************************************************************************
** File     : model.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
** */

#ifndef MODEL_H_
#define MODEL_H_

void initModel(void);
void updateModel(void);

#endif /* MODEL_H_ */
