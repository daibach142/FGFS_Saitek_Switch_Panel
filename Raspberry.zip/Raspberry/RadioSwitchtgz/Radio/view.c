/*****************************************************************************
 ** File     : view.c
 ** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
 ** Author   : Dave Attwood dave@attwoods.org.uk
 ** Copyright: (c) David Attwood 2020
 ** License  : GPL V3 or later
 ******************************************************************************
 */
#include <string.h>

#include "FGFSFunctions.h"
#include "STKRPFunctions.h"

#include "main.h"

#ifdef DEBUG
#include <stdio.h>
#endif
/***************************************************************************************************
 *
 */
void initView(void) {

	STKRPInit();
	FGFSInit();

}

void readInputs(void) {
	unsigned int result = STKRPRead();
	if (result != 0) {
#ifdef DEBUG
		printf("Read Inputs STKRP: %06x\n", result);
#endif
		// Instruments on display changed?
		if ((result & INSTRUMENTS) != (STKRPInput & INSTRUMENTS))
			STKRPUpdate(result & INSTRUMENTS);
		// Only if data read
		STKRPInput = result;
	}
	char *sresult = FGFSRead();
	if (strcmp(sresult, FGFSInput)) {
		// changed data
		strcpy(FGFSInput, sresult);
#ifdef DEBUG
		printf("Read Inputs FGFS: %s\n", sresult);
#endif
	}
}

void writeOutputs(void) {
	STKRPWrite();
	FGFSWrite();
}
