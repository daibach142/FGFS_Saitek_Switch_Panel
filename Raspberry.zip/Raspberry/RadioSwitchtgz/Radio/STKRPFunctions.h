/*****************************************************************************
** File     : STKRPFunctions.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
*/
#ifndef STKRPFUNCTIONS_H_
#define STKRPFUNCTIONS_H_

// Saitek Radio Panel 'udev' identifiers
// Vendor
#define SAITEK_VENDOR_ID	"06a3"
// Device
#define SAITEK_RADIO_DEVICE_ID	"0d05"


// returned 3 bytes from Saitek Radio Panel
// bit positions of flags, per byte
// byte 0
#define	TOPCOM1 0x010000
#define TOPCOM2 0x020000
#define TOPNAV1 0x040000
#define TOPNAV2 0x080000
#define TOPADF	0x100000
#define TOPDME	0x200000
#define TOPXPDR 0x400000
#define BOTCOM1 0x800000
// byte 1
#define BOTCOM2 0x0100
#define BOTNAV1 0x0200
#define BOTNAV2 0x0400
#define BOTADF	0x0800
#define BOTDME	0x1000
#define BOTXPDR	0x2000
#define TOPSW	0x4000
#define BOTSW	0x8000
// byte 2
#define TOPINCD 0x01
#define TOPDECD 0x02
#define TOPINC 	0x04
#define TOPDEC	0x08
#define BOTINCD	0x10
#define BOTDECD	0x20
#define BOTINC	0x40
#define BOTDEC	0x80

// For integer access (0x0000[byte0][byte1][byte2])
#define TOP_INSTRUMENTS (TOPCOM1 | TOPCOM2 | TOPNAV1 | TOPNAV2 | TOPADF | TOPDME | TOPXPDR)
#define BOTTOM_INSTRUMENTS (BOTCOM1 | BOTCOM2 | BOTNAV1 | BOTNAV2 | BOTADF | BOTDME | BOTXPDR)
#define INSTRUMENTS (TOP_INSTRUMENTS | BOTTOM_INSTRUMENTS)

// Useful for selecting display routines
#define TOP_COMS (TOPCOM1 | TOPCOM2 | TOPNAV1 | TOPNAV2)
#define BOTTOM_COMS (BOTCOM1 | BOTCOM2 | BOTNAV1 | BOTNAV2)
#define ALL_COMS ( TOP_COMS | BOTTOM_COMS)
#define ALL_ADF  (TOPADF | BOTADF)
#define ALL_DME  (TOPDME | BOTDME)
#define ALL_XPDR (TOPXPDR | BOTXPDR)

#define TOP_ROTARY    	(TOPINCD | TOPDECD | TOPINC | TOPDEC)
#define BOTTOM_ROTARY 	(BOTINCD | BOTDECD | BOTINC | BOTDEC)
#define ROTARY 			(TOP_ROTARY | BOTTOM_ROTARY)
#define SWITCHES		(TOPSW | BOTSW)



/*********************************************************************************************************
 * View accessible functions
 * *******************************************************************************************************
 */

void STKRPInit(void);
unsigned int STKRPRead(void);
void STKRPWrite();
void STKRPUpdate(int flags);
int STKRPGetRadioIndex(int top);

#endif /* STKRPFUNCTIONS_H_ */
