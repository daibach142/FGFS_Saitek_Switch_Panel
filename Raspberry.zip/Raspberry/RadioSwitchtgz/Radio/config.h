/* Name of package */
#define PACKAGE "saitek-radio-panel-driver"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "stkrp@attwoods.org.uk"

/* Define to the full name of this package. */
#define PACKAGE_NAME "Saitek Radio Panel Driver"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.2"


