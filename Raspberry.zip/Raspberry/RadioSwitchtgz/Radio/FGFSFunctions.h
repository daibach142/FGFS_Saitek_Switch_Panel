/*****************************************************************************
** File     : FGFSFunctions.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
*/

#ifndef FGFSFUNCTIONS_H_
#define FGFSFUNCTIONS_H_

#define PORT_IN  49001   		// The port on which to listen for incoming data
#define PORT_OUT 49002  		// The port on which WRITE  for modified data
#define FGFSOUTPUTBUFLEN (15)	// Max length of output (="transponder,4\n")

// Action codes for FGFS Nasal routines
#define ACTSW	(0)
#define ACTINCD	(1)
#define ACTDECD	(2)
#define	ACTINC	(3)
#define ACTDEC	(4)


void FGFSInit(void);			// Initialise FGFS interface
char * FGFSRead(void);			// return read string from FGFS as defined by Protocol/saitek_output.xml
void FGFSWrite(void);			// write to FGFS as defined by Protocol/saitek_input.xml
void FGFSSetState (int radionumber, int code); // save information for output by FGFSWrite later


#endif /* FGFSFUNCTIONS_H_ */
