/*****************************************************************************
** File     : Saitek.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
** */

// Output to the Radio Panel
#ifndef SAITEK_H_
#define SAITEK_H_

// For the Saitek Radio Panel, following funny constants

// Add into byte to set decimal point after on Panel display
#define DECFLAG (0xD0)
// Produce a blank position byte on Panel display
#define SPACE (0x0A)
// Subtract from numeric digit to get correct digit on Panel display
#define NUMBASE ('0')

typedef struct {
	/***************************************************************
	 * The Saitek Radio Panel has four 5 digit display areas.
	 * Top row has two labelled ACTIVE and STANDBY, the radio shown
	 * is indicated by the top selector switch.
	 * Bottom row is the same, using the bottom selector switch.
	 * Any data received from the STKRP always has the currently
	 * selected radios indicated.
	 */

	/***************************************************************
	 ** Index into the radio stack for the current value to convert
	 ***************************************************************
	 ** */
	int toplinefield;
	int botlinefield;
	/***************************************************************
	 ** Indicator to show display is currently OK (or not)
	 ***************************************************************
	 ** */
	int displayValid;
	/***************************************************************
	 ** Procedures to convert from the radio to the display
	 ** same function for active and standby
	 ** different function for top and bottom
	 ***************************************************************
	 ** */
	void (*display[2])(char * src, unsigned char * dest);
	/***************************************************************
	 ** Area for the displays - 5 bytes per display
	 ***************************************************************
	 ** */
	unsigned char displays[20];
	/***************************************************************
	 **
	 ***************************************************************
	 ** */




} SaitekDisplay_t;

void setRadio(char * src, unsigned char * dest);	// set display to dd.ddd
void setDME(char * src, unsigned char * dest);		// set display to distance and time/velocity
void setADF(char * src, unsigned char * dest);		// set display to ddd or dddd
void setXPDR(char * src, unsigned char * dest);		// set display to 0000 (4 octal digits)

#endif /* SAITEK_H_ */
