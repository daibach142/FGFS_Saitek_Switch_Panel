/*****************************************************************************
** File     : view.h
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
*/


#ifndef VIEW_H_
#define VIEW_H_

void initView(void);
void readInputs(void);
void writeOutputs(void);

#endif /* VIEW_H_ */
