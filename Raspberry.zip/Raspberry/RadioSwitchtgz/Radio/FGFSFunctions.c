/*****************************************************************************
** File     : FGFSFunctions.c
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
 */
#include "config.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include "main.h"

#include "FGFSFunctions.h"
#include "Instruments.h"

static char fgfsBuffer[sizeof(FGFSInput)];
static char * radio;
static int action = -1;

/***************************************************************
 * Initialise buffers etc
 * *************************************************************
 */
void FGFSInit(void) {
	FGFSInput[0] = 0;			// no input currently
}

/***************************************************************
 * Read a record from FGFS via UDP socket
 * and return a pointer to it.
 * Data format is defined in 'Protocol/saitek_output.xml'
 * *************************************************************
 */
char * FGFSRead(void) {

	struct sockaddr_in si_other;
	int s,	recv_len;
	//create UDP socket
	if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		perror("Simulator socket:");
		exit(-2);
	}

	memset((char *) &si_other, 0, sizeof(si_other));

	si_other.sin_family = AF_INET;
	si_other.sin_port = htons(PORT_IN);
	si_other.sin_addr.s_addr = htonl(INADDR_ANY);

	//bind socket to port - FGFS
	if (bind(s, (struct sockaddr*) &si_other, sizeof(si_other)) == -1) {
		perror("Simulator bind:");
		exit(-3);
	}

	memset(fgfsBuffer, 0x00, sizeof(fgfsBuffer));

	//try to receive some data, this is a blocking call
	if ((recv_len = recvfrom(s, fgfsBuffer, sizeof(fgfsBuffer), 0, NULL, NULL)) < 0) {
		perror("Simulator read:");
		exit(-4);
	}

	//disconnect
	close(s);
	return fgfsBuffer;
}

/*******************************************************************************************
 * Write a modification request to FGFS - code consists of a radio name eg: "nav[1]"
 * and an action number (1,2,4,8)
 * Data format expected by FGFS is defined in 'Protocol/saitek_input.xml' and is processed
 * with Nasal code in 'Nasal/Saitek.nas'
 * ******************************************************************************************
 */
void FGFSWrite(void) {
	// write radio and action code
	if(action < 0){
		return;
	}

	struct sockaddr_in si_other;
	int s;
	char outputBuffer[FGFSOUTPUTBUFLEN];

	int slen = sizeof(si_other);
	//connect
	if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		exit(-5);
	}

	memset((char *) &si_other, 0, sizeof(si_other));

	si_other.sin_family = AF_INET;
	si_other.sin_port  = htons(PORT_OUT);

	if (inet_aton(server , &si_other.sin_addr) == 0)
	{
		perror("Simulator inet_aton:");
		exit(-6);
	}

	memset(outputBuffer, 0, FGFSOUTPUTBUFLEN);

	strcpy(outputBuffer, radio);
	strcat(outputBuffer, ",");
	outputBuffer[strlen(outputBuffer)] = '0' + action;	// single digit, buffer is filled with \0
	strcat(outputBuffer, "\n");
	action = -1;
#ifdef DEBUG
	printf("writeDataFG: %s",outputBuffer);
#endif

	if (sendto(s, outputBuffer, strlen(outputBuffer), 0, (struct sockaddr *) &si_other, slen) == -1) {
			perror("Simulator write: ");
			exit(-7);
	}

	//Disconnect socket
	close(s);
}

/*************************************************************************************************
 * Essentially a setter for use by the model to save the selected radio and the action
 * ***********************************************************************************************
 */
void FGFSSetState (int radionumber, int code) {
	radio = getRadioName(radionumber);
	action = code;
}
