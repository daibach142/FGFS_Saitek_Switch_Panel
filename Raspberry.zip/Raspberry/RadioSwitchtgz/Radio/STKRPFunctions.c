/*****************************************************************************
 ** File     : STKRPFunctions.c
 ** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
 ** Author   : Dave Attwood dave@attwoods.org.uk
 ** Copyright: (c) David Attwood 2020
 ** License  : GPL V3 or later
 ******************************************************************************
 */
#include "config.h"

#ifdef HAVE_LIBUDEV_H
#include <libudev.h>
#endif

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "main.h"
#include "STKRPFunctions.h"
#include "Saitek.h"
#include "Instruments.h"

/**************************************************************************************************
 * Local variables
 * ************************************************************************************************
 */
static int stkrpFd;					// For reading and writing STKRP
static unsigned char buffer[3];		// Holds (last read) STKRP input
static unsigned int firstTime;		// To keep initial Radio selections

static SaitekDisplay_t theDisplay;	// What the Saitek Radio Panel is showing

/** *******************************************************************
 *  Lets go find the device (/dev/hidraw<x>)
 *  using the UDEV library and enable the STK Radio Panel
 *  *******************************************************************
 **/

void STKRPInit() {

	theDisplay.displayValid = 0;



#ifdef HAVE_LIBUDEV_H
	static const char * device;		// override the main.h definition?
	struct udev *udev;
	struct udev_enumerate *enumerate;
	struct udev_list_entry *devices;
	struct udev_list_entry *dev_list_entry;
	struct udev_device *dev;

	udev = udev_new();
	if (!udev) {
		printf("Can't create udev\n");
		exit(1);
	}

	/* create list of hidraw */
	enumerate = udev_enumerate_new(udev);
	udev_enumerate_add_match_subsystem(enumerate, "hidraw");
	udev_enumerate_scan_devices(enumerate);
	devices = udev_enumerate_get_list_entry(enumerate);
	udev_list_entry_foreach(dev_list_entry, devices)
	{
		const char *path;
		/* Get the filename of the /sys entry for the device
		 and create a udev_device object (dev) representing it */
		path = udev_list_entry_get_name(dev_list_entry);
		dev = udev_device_new_from_syspath(udev, path);

		/* usb_device_get_devnode() returns the path to the device node
		 itself in /dev. */
		device = udev_device_get_devnode(dev);  // eg. "/dev/hidraw4"

		/* The device pointed to by dev contains information about
		 the hidraw device. In order to get information about the
		 USB device, get the parent device with the
		 subsystem/devtype pair of "usb"/"usb_device". This will
		 be several levels up the tree, but the function will find
		 it.*/
		dev = udev_device_get_parent_with_subsystem_devtype(dev, "usb",
				"usb_device");
		if (!dev) {
			printf("Unable to find parent usb device.");
			exit(1);
		}

		/* From here, we can call get_sysattr_value() for each file
		 in the device's /sys entry. The strings passed into these
		 functions (idProduct, idVendor, serial, etc.) correspond
		 directly to the files in the directory which represents
		 the USB device. Note that USB strings are Unicode, UCS2
		 encoded, but the strings returned from
		 udev_device_get_sysattr_value() are UTF-8 encoded. */
		if (strcmp(udev_device_get_sysattr_value(dev, "idVendor"),
		SAITEK_VENDOR_ID) == 0
				&& strcmp(udev_device_get_sysattr_value(dev, "idProduct"),
				SAITEK_RADIO_DEVICE_ID) == 0) {
			// Gotcha!!
			udev_device_unref(dev);
			break;
		} else
			device = NULL;
		udev_device_unref(dev);
	}
	/* Free the enumerator object */
	udev_enumerate_unref(enumerate);
	udev_unref(udev);
#endif
	if (device != NULL) {
		printf("Saitek Radio on %s\n", device);
		stkrpFd = open(device, O_RDWR | O_NONBLOCK);

		if (stkrpFd < 0) {
			perror("Radio open:");
			exit(-1);
		}
	} else {
		printf("Saitek Radio Panel not plugged in\n");
		exit(-1);
	}

	// Write initial values to the displays
	for (int i = 0; i < 10; i++) {
		theDisplay.displays[i] = i + 1;
		theDisplay.displays[19 - i] = i;
	}
	theDisplay.displays[9] = 0;
	if (write(stkrpFd, theDisplay.displays, 20) < 20) {
		perror("Radio write:");
		exit(-2);
	}

	// enable the Saitek input by operating something
	printf("Operate ACT/STB key on the Saitek Radio\n");
	while (read(stkrpFd, buffer, sizeof(buffer)) < 0)
		sleep(1);
	printf("Saitek Radio Panel ready\n");
	// Here stkrpBuffer[0..1] have the selected radio devices for display
	// clean out any transient switch action
	firstTime = (buffer[0] << 16 | (buffer[1] << 8) | buffer[2]) & INSTRUMENTS;	// flag for data reader is current devices

	// for headless operation, let them know button press received
	printf("Button pressed\n");	
	for (int i = 1; i < 10; i+=2) {
		theDisplay.displays[i] = SPACE;
		theDisplay.displays[19 - i] = SPACE;
	}
	if (write(stkrpFd, theDisplay.displays, 20) < 0) {
		perror("Radio write:");
		exit(-4);
	}
}

/************************************************************************************************
 * STKRPRead reads the Saitek Radio Panel
 * returns an integer formed by the 3 bytes of data received packed into the l.s. bits
 * of the reply.
 * Data is described in 'saitek_technical_specifications'
 * **********************************************************************************************
 */
unsigned int STKRPRead(void) {
	if (firstTime) {
		unsigned int temp = firstTime;
		firstTime = 0;
		return temp;
	}

	if (read(stkrpFd, buffer, sizeof(buffer)) < 0) {
		return 0;
	}
	return ((buffer[0] << 16) | (buffer[1] << 8) | buffer[2]);
}

/**************************************************************************************************
 * Update the displays if required. Required if either selection of radios on display have changed,
 * or if the incoming radio values have changed
 * *************************************************************************************************
 */
void STKRPWrite() {
	if (!theDisplay.displayValid || getRadioChanged()) { // selection of radio, or radios value changed
			// two displays on top line, two on bottom
		theDisplay.display[0](getActive(theDisplay.toplinefield),
				&theDisplay.displays[0]);
		if (theDisplay.toplinefield != XPDR) {
			// transponder has no standby field
			theDisplay.display[0](getStandby(theDisplay.toplinefield),
					&theDisplay.displays[5]);
		}
		theDisplay.display[1](getActive(theDisplay.botlinefield),
				&theDisplay.displays[10]);
		if (theDisplay.botlinefield != XPDR) {
			// transponder has no standby field
			theDisplay.display[1](getStandby(theDisplay.botlinefield),
					&theDisplay.displays[15]);
		}
		theDisplay.displayValid = 1;
		if (write(stkrpFd, theDisplay.displays, 20) < 0) {
			perror("Radio write:");
			exit(-5);
		}
	}
}
/*******************************************************************************************
 * Updates the display configuration to show newly selected radios
 * This will eventually be sent by View to the STKRPWrite routine for output
 * *****************************************************************************************
 */
void STKRPUpdate(int instruments) {
	// need to map the device flags to the radios
	if (instruments & ALL_COMS) {
		// radios with 'ddd.dd' display
		if (instruments & TOP_COMS) {
			theDisplay.toplinefield = (instruments & TOPCOM1) ? COM1 :
										(instruments & TOPCOM2) ? COM2 :
										(instruments & TOPNAV1) ? NAV1 : NAV2;
			theDisplay.display[0] = setRadio;
		}
		if (instruments & BOTTOM_COMS) {
			theDisplay.botlinefield = (instruments & BOTCOM1) ? COM1 :
										(instruments & BOTCOM2) ? COM2 :
										(instruments & BOTNAV1) ? NAV1 : NAV2;
			theDisplay.display[1] = setRadio;
		}
	}
	// ADF is 3 or 4 digits integer
	if (instruments & TOPADF) {
		theDisplay.toplinefield = ADF;
		theDisplay.display[0] = setADF;
	}
	if (instruments & BOTADF) {
		theDisplay.botlinefield = ADF;
		theDisplay.display[1] = setADF;
	}
	// dme has miles 'dd.d' and time or speed 1, 2 or 3 digits
	if (instruments & TOPDME) {
		theDisplay.toplinefield = DME;
		theDisplay.display[0] = setDME;
	}
	if (instruments & BOTDME) {
		theDisplay.botlinefield = DME;
		theDisplay.display[1] = setDME;
	}
	// transponder is 4 (octal) digits
	if (instruments & TOPXPDR) {
		theDisplay.toplinefield = XPDR;
		theDisplay.display[0] = setXPDR;
	}
	if (instruments & BOTXPDR) {
		theDisplay.botlinefield = XPDR;
		theDisplay.display[1] = setXPDR;
	}
	// changed - make sure it gets displayed
	theDisplay.displayValid = 0;

}

/****************************************************************************************
 * Fills a buffer with (STKRP) spaces
 * **************************************************************************************
 */
void blankout(unsigned char *dest, int length) {
	while (length--) {
		*dest++ = SPACE;
	}
}

/***************************************************************************************
 * Sets a comm-type radio value 'ddd.dd'
 * *************************************************************************************
 */
void setRadio(char *source, unsigned char *dest) {
	// Fix: #3 Github issue segfault
	if (strlen(source) == 0) {
		blankout(dest, 5);
	} else {
		for (int i = 0; i < 6; i++) {
			if (source[i] != '.') {
				unsigned char byte = source[i] - NUMBASE;
				if (i == 2)
					byte += DECFLAG;
				*dest++ = byte;
			}
		}
	}
}


/****************************************************************************************
 * Sets ADF frequency as digits, no leading zeros
 * **************************************************************************************
 */
void setADF(char *source, unsigned char *dest) {
// 3 or 4 ADF frequency digits
	blankout(dest, 5);
	int len = strlen(source);
	for (int i = 0; i < len; i++)
		dest[5 - len + i] = source[i] - NUMBASE;
}

/*****************************************************************************************
 * Set DME distance
 * ***************************************************************************************
 */
void distanceToDME(char *source, unsigned char *dest) {
	// digits may have up to 2 integral digits and one decimal place
	blankout(dest, 5);
	int len = strlen(source);
	// DME is usually maxed around 70 nm
	if (len == 1) {
		dest[3] = '0' - NUMBASE;
		dest[4] = source[0] - NUMBASE;
	} else if (len == 2) {
		dest[3] = source[0] - NUMBASE;
		dest[4] = source[1] - NUMBASE;
	} else if (len == 3) {
		dest[2] = source[0] - NUMBASE;
		dest[3] = source[1] - NUMBASE;
		dest[4] = source[2] - NUMBASE;
	}
	// add the decimal point
	if (len > 0)
		dest[3] += DECFLAG;
}

/**************************************************************************************************
 * Set DME velocity or time integers
 * ************************************************************************************************
 */
void velocityToDME(char *source, unsigned char *dest) {
	// up to 3 digits of speed or time (no decimal point)
	blankout(dest, 5);
	int pos = strlen(source) - 1;
	if (pos < 0)
		return;
	dest[4] = source[pos] - NUMBASE;  // last digit
	pos--;
	if (pos >= 0)
		dest[3] = source[pos] - NUMBASE; // next to last if any
	pos--;
	if (pos >= 0)
		dest[2] = source[pos] - NUMBASE; // 1st of 3 if any
}

/*************************************************************************************************
 * Fill in DME active and standby
 * ***********************************************************************************************
 */
void setDME(char *source, unsigned char *dest) {
	// produce both active and standby together
	// this will probably be called twice so keep track!
	static int mode = 0;
	if (mode == 0) {
		distanceToDME(source, dest);
		mode = 1;
	} else {
		velocityToDME(source, dest);
		mode = 0;
	}
}

/************************************************************************************************
 * Fill in Transponder - blank in active and 4 octals in standby
 * **********************************************************************************************
 */
void setXPDR(char *source, unsigned char *dest) {
	blankout(dest, 6);
	int length = strlen(source);
	if (length > 0) {
		// check for trailing NL as this is the last item from 'flightgear'
		if (source[length - 1] == '\n')
			length--;
	}
// allow for leading zeroes
	for (int i = 6; i < 10; i++)
		dest[i] = '0' - NUMBASE;
	for (int i = 0; i < length; i++)
		dest[i + 10 - length] = source[i] - NUMBASE;
}

/**************************************************************************************************
 * Simple getter for top or bottom active radio
 * ************************************************************************************************
 */
int STKRPGetRadioIndex(int top) {
	return (top) ? theDisplay.toplinefield : theDisplay.botlinefield;
}
