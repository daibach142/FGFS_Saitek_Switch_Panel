/*****************************************************************************
 ** File     : model.c
 ** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
 ** Author   : Dave Attwood dave@attwoods.org.uk
 ** Copyright: (c) David Attwood 2020
 ** License  : GPL V3 or later
 ******************************************************************************
 ** */
#include <string.h>

#include "main.h"
#include "STKRPFunctions.h"
#include "Instruments.h"
#include "FGFSFunctions.h"

static unsigned int STKRPCurrent = 0;				// current value from Saitek Radio Panel
static char FGFSCurrent[sizeof(FGFSInput)] = { 0 }; // current transmission from Flight Gear Flight Sim
static char FGFSParsed[sizeof(FGFSInput)];			// holds the individual strings per radio device
static char *Radios[7][2]; 							// COM1, COM2, NAV1, Nav2, ADF, DME, XPDR strings as input
static char RadioNames[7][13] = { "comm", "comm[1]", "nav", "nav[1]", "adf",
		"dme", "transponder" };
static int RadiosChanged = 0;						// to tell STKRP code to update display


/******************************************************************************************************
 * perform initialisation for the model
 * ****************************************************************************************************
 */
void initModel(void) {
	// looks like nothing to do!
}
/******************************************************************************************************
 * Update the model code after receiving input from STKRP and FGFS
 * ****************************************************************************************************
 */
void updateModel(void) {
	// Process Saitek input first
	if (STKRPInput != STKRPCurrent) {
		// data change - can be radio selection switch or a rotary control
		STKRPCurrent = STKRPInput;
		if (STKRPInput & ROTARY) {
			// knob twiddling
			int rottype = STKRPInput & ROTARY;
			// the format is : ls 4 bits, top rotary controls
			//                 ms 4 bits, bottom rotary controls
			int top = (STKRPInput & TOP_ROTARY); 		// 0 if bottom, non-zero otherwise!
			int radionum = STKRPGetRadioIndex(top);		// smart routine returns top or bottom radio as required
			if (!top)
				rottype >>= 4;							// now, bottom 4 bits
			FGFSSetState(radionum, rottype);			// FGFS needs to know about knob twiddling
		} else if (STKRPInput & SWITCHES) {
			// switch swaps active and standby radios, FGFS needs to know this
			FGFSSetState(STKRPGetRadioIndex((STKRPCurrent & TOPSW) ? 1 : 0),
			ACTSW);
		}
		// there is no processing required by FGFS if radio on display is changed, so no action required here
	}
	// then process data from FGFS
	if (strcmp(FGFSCurrent, FGFSInput)) {
		strcpy(FGFSCurrent, FGFSInput);
		strcpy(FGFSParsed, FGFSInput);

		// fixed: #3 Github issue
		char * movingPointer = FGFSParsed;

		// get new values for the radios
		// this is slightly destructive on FGFSParsed
		// active and standby display for all but transponder
		// order of radios received is defined by 'Protocol/saitek_output.xml'
		for (int i = 0; i < 6; i++)
			for (int j = 0; j < 2; j++)
				Radios[i][j] =	strsep(&movingPointer, ",");
		Radios[6][0] = strsep(&movingPointer, "\n");
		RadiosChanged = 1;
	} else {
		RadiosChanged = 0;		// no further action by controller
	}

}

/**********************************************************************************************************
 * Various getters required by View routines
 * ********************************************************************************************************
 */

char* getActive(int deviceNumber) {
	return Radios[deviceNumber][0];
}
char* getStandby(int deviceNumber) {
	return Radios[deviceNumber][1];
}
char* getRadioName(int deviceNumber) {
	return RadioNames[deviceNumber];
}

int getRadioChanged(void) {
	return RadiosChanged;
}
