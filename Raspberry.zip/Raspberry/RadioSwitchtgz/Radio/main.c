/*****************************************************************************
** File     : main.c
** Project  : Flight Gear Flight Simulator to Saitek Radio Panel Interface
** Author   : Dave Attwood dave@attwoods.org.uk
** Copyright: (c) David Attwood 2020
** License  : GPL V3 or later
******************************************************************************
** */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>

#include "main.h"
#include "config.h"		// from autoconf
#include "model.h"
#include "view.h"

static volatile int keepRunning = 1;

void intHandler(int p);
/*****************************************************************************
 *
 * The program flow is as follows:
 *  	Read the Radio Panel (O_NONBLOCK) and a blocking read on FGFS
 *    	Update the items to display on Radio Panel if select changed
 *    	Parse the FGFS radio values into fields
 *    	If Radio Panel or the FGFS input has changed, update the Panel
 *    	If a rotary switch or ACT/STBY was operated, write to FGFS
 *  and repeat
 *  Note: changing the displayed radio on the panel requires no extra
 *  data from FGFS
 *  *************************************************************************/

int main(int argc, char *argv[]) {

//	strcpy(device, DEVICE); 	/* built in default device */
//	strcpy(server, SERVER);		/* built in local server */

	while (1) {
		int c;
		int optionIndex = 0;
		static struct option longOptions[] = {
				{"device",	required_argument, 	0, 'd'},
				{"flightgear",	required_argument, 	0, 'f'},
				{0,			0,					0,	0}
		};
		c = getopt_long(argc, argv, "d:f:",
		                longOptions, &optionIndex);
		if (c == -1)
			break;

		switch (c) {
		case 'd':
			strncpy(device, optarg, sizeof(device));
			break;

		case 'f':
			strncpy(server, optarg, sizeof(server));
			break;

		default:
			break;	/* not good argument */
		}

	}

	printf("This is " PACKAGE_NAME " Version " PACKAGE_VERSION " on device %s to FGFS at %s\n", device, server);

	signal(SIGINT, intHandler);

	initModel();
	initView();

	while (keepRunning) {
		readInputs();
		updateModel();
		writeOutputs();
	}
	return EXIT_SUCCESS;
}
/********************************************************************
 * Here on SIGINT to stop running
 * parameter p: the signal code
 * ******************************************************************
 */
void intHandler(int p) {
	keepRunning = 0;

}
