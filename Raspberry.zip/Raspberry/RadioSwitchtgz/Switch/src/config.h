/* Name of package */
#define PACKAGE "saitek-switch-driver"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "stksw@attwoods.org.uk"

/* Define to the full name of this package. */
#define PACKAGE_NAME "Saitek Switch Panel Driver"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.1"


